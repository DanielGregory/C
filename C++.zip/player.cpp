/* File: card.cpp
 * Course: CS215-008
 * Project: Project 3
 * Purpose: the implementation of member functions for the Card class.
 * Author: Daniel Gregory
 */
#include "player.h"
#include <iostream>

using namespace std;

// default constructor
Player::Player()
    : numCards(0)
{
}

// alternative constructor
Player::Player(vector<Card> ini_cards)
    : numCards(ini_cards.size()), cards(ini_cards.begin(), ini_cards.end())
{
}
// return how many cards player holds currently
int Player::getNumCards() const
{
    return numCards;
}

// player plays one card from the front of cards at hand
Card Player::play_a_card()
{
    Card c = cards.front();
    cards.pop_front();
    numCards--;
    return c;
}
// when the player wins the round, this function will be called
// player adds winning cards to the end of the cards at hand
void Player::addCards(vector<Card> winningCards)
{
    for (Card c : winningCards) {
        cards.push_back(c);
        numCards++;
    }
}
// when there is a tie, this function will be called
// player drops THREE cards from the front of cards at hand
vector<Card> Player::dropCards()
{
    vector<Card> droppedCards;
    for (int i = 0; i < 3; i++) {
        Card c = cards.front();
        cards.pop_front();
        numCards--;
        droppedCards.push_back(c);
    }
    return droppedCards;
}
// display cards at player's hand
void Player::print() const {
    cout << "Player's hand: ";
    for (auto it = cards.begin(); it != cards.end(); it++) {
        cout << it->getPoint() << it->getSuit() << " ";
    }
    cout << endl;
}