/*
* Course: CS215 - 008
* Project : Lab 10 (for the purpose of testing Player class)
* Purpose : Testing the definition of Player class.
* First, it creates 52 cards on deck(no shuffle)
* Second, it deals 26 cards for one player : testPlayer(another 26 cards are put on the pile at table)
* Third, testPlayer plays one card from hand, then drop THREE cards from hand
* Fourth, testPlayer plays one more card from hand
* Then "pretend" testPlayer wins and get FIVE cards on the pile(at the table) and it displays cards in player1's hand and in player2's hand respectively
* Last, display simulation : testPlayer repeatedly plays ONE card, then drops THREE cards, until no more card in hand.
* Author: Daniel Gregory
*/
#include <iostream>
#include <algorithm>
#include "card.h"
#include "deck.h"
#include "player.h"

using namespace std;

int main() {
    Deck deck;  // create a deck of cards
    vector<Card> pile;  // create a pile to store the cards played by each player
    vector<Card> p1_cards, p2_cards;
   
    deck.createDeck();
    deck.shuffleDeck();  // shuffle the deck
    for (int i = 0; i < 26; i++)
    {
        p1_cards.push_back(deck.deal_a_card());
        p2_cards.push_back(deck.deal_a_card());

    }  // deal the cards to the players

     Player player1(p1_cards), player2(p2_cards);  // create two players
    char choice;
    do {
        // Play one round of the game
        Card card1 = player1.play_a_card();  // player 1 plays a card
        Card card2 = player2.play_a_card();  // player 2 plays a card

        // Display the cards played by each player
        cout << "Player 1: ";
        card1.print();
        cout << endl;
        cout << "Player 2: ";
        card2.print();
        cout << endl;
        cout << "----------------------------------------------" << endl << endl;
        // Add the cards to the pile
        pile.push_back(card1);
        pile.push_back(card2);

        // Display how many cards on the pile
        cout << "There are " << pile.size() << " cards on the pile!"<<endl << endl;
        cout << "----------------------------------------------" << endl;

        // Compare the cards played by each player
        int result = card1.compareTo(card2);
        if (result > 0) {
            // player 1 wins
            cout << "Player 1 wins...get all cards from the pile!" << endl;
            player1.addCards(pile);  // add the cards in the pile to player 1's hand
            pile.clear();  // clear the pile 
            // Display how many cards in each player's hand
        cout << "Player 1 has " << player1.getNumCards() << " cards in hand." << endl;
        cout << "Player 2 has " << player2.getNumCards() << " cards in hand." << endl<<endl;
        }
        else if (result < 0) {
            // player 2 wins
            cout << "Player 2 wins...get all cards from the pile!" << endl;
            player2.addCards(pile);  // add the cards in the pile to player 2's hand
            pile.clear();  // clear the pile
            // Display how many cards in each player's hand
            cout << "Player 1 has " << player1.getNumCards() << " cards in hand." << endl;
            cout << "Player 2 has " << player2.getNumCards() << " cards in hand." << endl << endl;
        }
        else {
            if (player1.getNumCards() < 4 && pile.size()<45)
            {
                cout << "Player 2 wins the game.";
                    break;
            }
            else if(player2.getNumCards()<4 && pile.size() < 45){
                cout << "Player 1 wins the game.";
                    break;
            }
            else if (player1.getNumCards() == 1 && player2.getNumCards() == 1) {
                cout << "It is a tie...for this round!" << endl;
                cout << "Each player drops three cards (face down) on the pile, then\nplay one more card (face up)" << endl;
                cout << "Game is over!" << endl;
                cout << "It is a tie game!" << endl;
                cout << "Player 1 has " << player1.getNumCards() << " cards in hand." << endl;
                cout << "Player 2 has " << player2.getNumCards() << " cards in hand." << endl;
                break;
            }
            // it is a tie
            cout << "It is a tie...for this round!" << endl;
            cout << "Each player drops three cards (face down) on the pile, then\nplay one more card (face up)" << endl;
            pile.push_back(player1.play_a_card());  
            pile.push_back(player2.play_a_card());  
            pile.push_back(player1.play_a_card());  
            pile.push_back(player2.play_a_card());  
            pile.push_back(player1.play_a_card());  
            pile.push_back(player2.play_a_card());  
            cout << "----------------------------------------------" << endl<<endl;
            cout << "There are " << pile.size() << " cards on the pile!" << endl << endl;
            cout << "----------------------------------------------" << endl << endl;
            cout << "Player 1 has " << player1.getNumCards() << " cards in hand." << endl;
            cout << "Player 2 has " << player2.getNumCards() << " cards in hand." << endl << endl;
        }

       

        // Check if the game is over
        if (player1.getNumCards() <= 0) {
            cout << "Player 2 wins the game!" << endl;
            break;
        }
        if (player2.getNumCards() <=0 ) {
            cout << "Player 1 wins the game!" << endl;
            break;
        }

        // Ask the user if they want to continue to the next round
        cout << "Do you want to continue to the next round? (N or n to quit) ";
        char response;
        cin.get(response);
        if (response == '\n')
        {
           
            continue;
        }
        cin.ignore(256, '\n');
        if (response == 'n' || response == 'N') {
            cout << "You choose to quit the game" << endl;
            cout << "Player 1 has " << player1.getNumCards() << " cards left." << endl;
            cout << "Player 2 has " << player2.getNumCards() << " cards left." << endl;
            break;
        }
    } while (1);
    return 0;
}
